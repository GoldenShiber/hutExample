package com.hutbooking.hut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HutApplicationTests {

	@Test
	void contextLoads() {
	}

}
